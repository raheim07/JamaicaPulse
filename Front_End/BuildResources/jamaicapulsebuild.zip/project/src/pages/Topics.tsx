import { useEffect, useState } from 'react';
import { apiService } from '../services/api';
import { Doughnut, Line } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

export default function Topics() {
  const [topics, setTopics] = useState<any[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string>('');
  const [topicDetail, setTopicDetail] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await apiService.getTopics();
        setTopics(response.data);
        if (response.data.length > 0) {
          setSelectedTopic(response.data[0].name);
        }
      } catch (error) {
        console.error('Error fetching topics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTopics();
  }, []);

  useEffect(() => {
    if (selectedTopic) {
      const fetchTopicDetail = async () => {
        try {
          const response = await apiService.getTopicDetails(selectedTopic);
          setTopicDetail(response.data);
        } catch (error) {
          console.error('Error fetching topic detail:', error);
        }
      };

      fetchTopicDetail();
    }
  }, [selectedTopic]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-emerald-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 font-medium">Loading topics...</p>
        </div>
      </div>
    );
  }

  const currentTopic = topics.find(t => t.name === selectedTopic);

  const emotionChartData = currentTopic ? {
    labels: ['Positive', 'Negative', 'Neutral'],
    datasets: [
      {
        data: [
          currentTopic.positive * 100,
          currentTopic.negative * 100,
          currentTopic.neutral * 100
        ],
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(156, 163, 175, 0.8)'
        ],
        borderColor: [
          'rgb(34, 197, 94)',
          'rgb(239, 68, 68)',
          'rgb(156, 163, 175)'
        ],
        borderWidth: 2
      }
    ]
  } : null;

  const trendChartData = topicDetail?.trend ? {
    labels: topicDetail.trend.map((d: any) =>
      new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    ),
    datasets: [
      {
        label: 'Sentiment Score',
        data: topicDetail.trend.map((d: any) => d.sentiment),
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        fill: true,
        tension: 0.4
      }
    ]
  } : null;

  const trendOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        min: 0,
        max: 100
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Topic Insights</h1>
          <p className="text-gray-600">Explore sentiment by category</p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg mb-8">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Topic
          </label>
          <select
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            className="w-full md:w-64 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
          >
            {topics.map(topic => (
              <option key={topic.name} value={topic.name}>
                {topic.name}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {emotionChartData && (
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-800 mb-6">
                Emotion Distribution: {selectedTopic}
              </h3>
              <div className="h-80 flex items-center justify-center">
                <Doughnut data={emotionChartData} />
              </div>
              {currentTopic && (
                <div className="mt-6 grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-700">
                      {(currentTopic.positive * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-600">Positive</div>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-700">
                      {(currentTopic.negative * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-600">Negative</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-700">
                      {(currentTopic.neutral * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-600">Neutral</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {trendChartData && (
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-800 mb-6">
                7-Day Trend: {selectedTopic}
              </h3>
              <div className="h-80">
                <Line data={trendChartData} options={trendOptions} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
