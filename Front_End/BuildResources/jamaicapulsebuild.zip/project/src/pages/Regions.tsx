import { useEffect, useState } from 'react';
import { apiService } from '../services/api';
import { MapPin, TrendingUp, TrendingDown } from 'lucide-react';

export default function Regions() {
  const [regions, setRegions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  useEffect(() => {
    const fetchRegions = async () => {
      try {
        const response = await apiService.getRegions();
        setRegions(response.data);
      } catch (error) {
        console.error('Error fetching regions:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRegions();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-emerald-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 font-medium">Loading regional data...</p>
        </div>
      </div>
    );
  }

  const getSentimentScore = (region: any) => {
    return (region.positive * 100 - region.negative * 100 + 50);
  };

  const getSentimentColor = (score: number) => {
    if (score >= 60) return 'bg-green-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getSentimentGradient = (score: number) => {
    if (score >= 60) return 'from-green-500 to-emerald-600';
    if (score >= 40) return 'from-yellow-500 to-orange-500';
    return 'from-red-500 to-rose-600';
  };

  const sortedRegions = [...regions].sort((a, b) => getSentimentScore(b) - getSentimentScore(a));
  const topRegions = sortedRegions.slice(0, 3);
  const bottomRegions = sortedRegions.slice(-3).reverse();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Regional Pulse</h1>
          <p className="text-gray-600">Parish-level sentiment across Jamaica</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
              <TrendingUp className="w-6 h-6 mr-2 text-green-500" />
              Most Positive Parishes
            </h3>
            <div className="space-y-4">
              {topRegions.map((region) => {
                const score = getSentimentScore(region);
                return (
                  <div
                    key={region.parish}
                    className={`p-4 rounded-xl bg-gradient-to-r ${getSentimentGradient(score)} text-white shadow-md`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <MapPin className="w-5 h-5 mr-2" />
                        <span className="font-bold text-lg">{region.parish}</span>
                      </div>
                      <span className="text-2xl font-bold">{score.toFixed(0)}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.positive * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Positive</div>
                      </div>
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.negative * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Negative</div>
                      </div>
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.neutral * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Neutral</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
              <TrendingDown className="w-6 h-6 mr-2 text-red-500" />
              Most Concerned Parishes
            </h3>
            <div className="space-y-4">
              {bottomRegions.map((region) => {
                const score = getSentimentScore(region);
                return (
                  <div
                    key={region.parish}
                    className={`p-4 rounded-xl bg-gradient-to-r ${getSentimentGradient(score)} text-white shadow-md`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <MapPin className="w-5 h-5 mr-2" />
                        <span className="font-bold text-lg">{region.parish}</span>
                      </div>
                      <span className="text-2xl font-bold">{score.toFixed(0)}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.positive * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Positive</div>
                      </div>
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.negative * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Negative</div>
                      </div>
                      <div className="bg-white/20 rounded px-2 py-1 text-center">
                        <div className="font-semibold">{(region.neutral * 100).toFixed(0)}%</div>
                        <div className="text-xs opacity-90">Neutral</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-6">All Parishes</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedRegions.map((region) => {
              const score = getSentimentScore(region);
              const isHovered = hoveredRegion === region.parish;

              return (
                <div
                  key={region.parish}
                  onMouseEnter={() => setHoveredRegion(region.parish)}
                  onMouseLeave={() => setHoveredRegion(null)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isHovered
                      ? 'border-emerald-500 shadow-lg scale-105'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full ${getSentimentColor(score)} mr-2`} />
                      <span className="font-bold text-gray-800">{region.parish}</span>
                    </div>
                    <span className="text-xl font-bold text-gray-700">{score.toFixed(0)}</span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Positive</span>
                      <div className="flex items-center">
                        <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${region.positive * 100}%` }}
                          />
                        </div>
                        <span className="font-medium w-10 text-right">
                          {(region.positive * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Negative</span>
                      <div className="flex items-center">
                        <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className="bg-red-500 h-2 rounded-full"
                            style={{ width: `${region.negative * 100}%` }}
                          />
                        </div>
                        <span className="font-medium w-10 text-right">
                          {(region.negative * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Neutral</span>
                      <div className="flex items-center">
                        <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className="bg-gray-500 h-2 rounded-full"
                            style={{ width: `${region.neutral * 100}%` }}
                          />
                        </div>
                        <span className="font-medium w-10 text-right">
                          {(region.neutral * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
