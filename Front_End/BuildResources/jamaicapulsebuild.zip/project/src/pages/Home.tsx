import { useEffect, useState } from 'react';
import { apiService } from '../services/api';
import PulseIndexCard from '../components/PulseIndexCard';
import TrendGraph from '../components/TrendGraph';
import TopTopics from '../components/TopTopics';
import RegionalMap from '../components/RegionalMap';

export default function Home() {
  const [pulse, setPulse] = useState<any>(null);
  const [trends, setTrends] = useState<any[]>([]);
  const [topics, setTopics] = useState<any[]>([]);
  const [regions, setRegions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [pulseRes, trendsRes, topicsRes, regionsRes] = await Promise.all([
          apiService.getPulse(),
          apiService.getTrends(7),
          apiService.getTopics(),
          apiService.getRegions()
        ]);

        setPulse(pulseRes.data);
        setTrends(trendsRes.data);
        setTopics(topicsRes.data);
        setRegions(regionsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-emerald-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 font-medium">Loading pulse data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Jamaica's Pulse</h1>
          <p className="text-gray-600">Real-time sentiment analysis of the nation</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {pulse && (
            <PulseIndexCard
              index={pulse.index}
              label={pulse.label}
              trend={pulse.trend}
              lastUpdated={pulse.lastUpdated}
            />
          )}
          {trends.length > 0 && <TrendGraph data={trends} />}
        </div>

        {topics.length > 0 && (
          <div className="mb-8">
            <TopTopics topics={topics} />
          </div>
        )}

        {regions.length > 0 && <RegionalMap regions={regions} />}
      </div>
    </div>
  );
}
