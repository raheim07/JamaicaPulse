const mockData = {
  pulse: {
    index: 68,
    label: "Optimistic",
    trend: "up",
    lastUpdated: "2025-10-18T10:00Z"
  },
  trends: [
    { date: "2025-10-12", sentiment: 62 },
    { date: "2025-10-13", sentiment: 65 },
    { date: "2025-10-14", sentiment: 59 },
    { date: "2025-10-15", sentiment: 68 },
    { date: "2025-10-16", sentiment: 71 },
    { date: "2025-10-17", sentiment: 67 },
    { date: "2025-10-18", sentiment: 68 }
  ],
  topics: [
    { name: "Education", positive: 0.45, negative: 0.25, neutral: 0.30 },
    { name: "Crime", positive: 0.15, negative: 0.70, neutral: 0.15 },
    { name: "Economy", positive: 0.30, negative: 0.50, neutral: 0.20 },
    { name: "Healthcare", positive: 0.40, negative: 0.35, neutral: 0.25 },
    { name: "Transport", positive: 0.25, negative: 0.60, neutral: 0.15 }
  ],
  regions: [
    { parish: "Kingston", positive: 0.35, negative: 0.45, neutral: 0.20 },
    { parish: "St. Andrew", positive: 0.40, negative: 0.35, neutral: 0.25 },
    { parish: "St. Catherine", positive: 0.30, negative: 0.50, neutral: 0.20 },
    { parish: "Clarendon", positive: 0.38, negative: 0.40, neutral: 0.22 },
    { parish: "Manchester", positive: 0.42, negative: 0.33, neutral: 0.25 },
    { parish: "St. Elizabeth", positive: 0.45, negative: 0.30, neutral: 0.25 },
    { parish: "Westmoreland", positive: 0.41, negative: 0.35, neutral: 0.24 },
    { parish: "Hanover", positive: 0.48, negative: 0.28, neutral: 0.24 },
    { parish: "St. James", positive: 0.32, negative: 0.48, neutral: 0.20 },
    { parish: "Trelawny", positive: 0.44, negative: 0.31, neutral: 0.25 },
    { parish: "St. Ann", positive: 0.50, negative: 0.25, neutral: 0.25 },
    { parish: "St. Mary", positive: 0.43, negative: 0.34, neutral: 0.23 },
    { parish: "Portland", positive: 0.52, negative: 0.23, neutral: 0.25 },
    { parish: "St. Thomas", positive: 0.39, negative: 0.38, neutral: 0.23 }
  ],
  topicDetails: {
    Education: {
      trend: [
        { date: "2025-10-12", sentiment: 58 },
        { date: "2025-10-13", sentiment: 62 },
        { date: "2025-10-14", sentiment: 60 },
        { date: "2025-10-15", sentiment: 67 },
        { date: "2025-10-16", sentiment: 70 },
        { date: "2025-10-17", sentiment: 68 },
        { date: "2025-10-18", sentiment: 72 }
      ]
    },
    Crime: {
      trend: [
        { date: "2025-10-12", sentiment: 35 },
        { date: "2025-10-13", sentiment: 32 },
        { date: "2025-10-14", sentiment: 30 },
        { date: "2025-10-15", sentiment: 33 },
        { date: "2025-10-16", sentiment: 36 },
        { date: "2025-10-17", sentiment: 34 },
        { date: "2025-10-18", sentiment: 37 }
      ]
    },
    Economy: {
      trend: [
        { date: "2025-10-12", sentiment: 45 },
        { date: "2025-10-13", sentiment: 48 },
        { date: "2025-10-14", sentiment: 42 },
        { date: "2025-10-15", sentiment: 47 },
        { date: "2025-10-16", sentiment: 50 },
        { date: "2025-10-17", sentiment: 49 },
        { date: "2025-10-18", sentiment: 51 }
      ]
    },
    Healthcare: {
      trend: [
        { date: "2025-10-12", sentiment: 52 },
        { date: "2025-10-13", sentiment: 55 },
        { date: "2025-10-14", sentiment: 53 },
        { date: "2025-10-15", sentiment: 58 },
        { date: "2025-10-16", sentiment: 60 },
        { date: "2025-10-17", sentiment: 57 },
        { date: "2025-10-18", sentiment: 62 }
      ]
    },
    Transport: {
      trend: [
        { date: "2025-10-12", sentiment: 40 },
        { date: "2025-10-13", sentiment: 38 },
        { date: "2025-10-14", sentiment: 35 },
        { date: "2025-10-15", sentiment: 42 },
        { date: "2025-10-16", sentiment: 45 },
        { date: "2025-10-17", sentiment: 43 },
        { date: "2025-10-18", sentiment: 44 }
      ]
    }
  }
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const apiService = {
  getPulse: async () => {
    await delay(500);
    return { data: mockData.pulse };
  },

  getTrends: async (days: number = 7) => {
    await delay(500);
    return { data: mockData.trends.slice(-days) };
  },

  getTopics: async () => {
    await delay(500);
    return { data: mockData.topics };
  },

  getRegions: async () => {
    await delay(500);
    return { data: mockData.regions };
  },

  getTopicDetails: async (topic: string) => {
    await delay(500);
    const topicData = mockData.topics.find(t => t.name === topic);
    const trendData = mockData.topicDetails[topic as keyof typeof mockData.topicDetails];
    return {
      data: {
        ...topicData,
        trend: trendData?.trend || []
      }
    };
  }
};
